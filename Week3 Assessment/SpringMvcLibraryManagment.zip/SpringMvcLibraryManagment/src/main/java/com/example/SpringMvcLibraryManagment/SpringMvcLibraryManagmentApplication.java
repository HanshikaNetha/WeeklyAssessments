package com.example.SpringMvcLibraryManagment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcLibraryManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcLibraryManagmentApplication.class, args);
	}

}
