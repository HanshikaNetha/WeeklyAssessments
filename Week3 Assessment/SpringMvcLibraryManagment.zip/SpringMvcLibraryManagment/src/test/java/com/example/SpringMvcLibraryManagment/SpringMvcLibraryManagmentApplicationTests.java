package com.example.SpringMvcLibraryManagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcLibraryManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
